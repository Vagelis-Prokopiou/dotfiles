Search Krumo extends the devel module.

FUNCTIONALITY:
==============

Search:
-------
You can search for keys or values.

Variable path:
--------------
You can copy the path to an item in an array/object.
Example: $variables['page']->node->nid
To fully use this function use sdpm instead of dpm.
This will add the variable name that you have put into sdpm()
This way it is only copy and paste, the best for hard working/lazy programmers!
