<?php

namespace Drupal\Tests\Core\Database\Stub;

use Drupal\Core\Database\Driver\mysql\Select as QuerySelect;

class Select extends QuerySelect {

}
