
Installation:

You can install the module as usual. 

Configuration:
1. Create a field group in Store > Configuration > Order settings > Manage Fields
2. Enable the pane in Store > Configuration > Checkout settings


